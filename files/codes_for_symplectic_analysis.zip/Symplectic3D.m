%%%============================Copyright============================%%%
%%% Version Nov. 10, 2024
%%%
%%% Lizichen Chen <lzcchen@zju.edu.cn>
%%% Department of Engineering Mechanics, Zhejiang University
%%%
%%%===========================Description===========================%%%
%%% Symplectic analyses for 3D contact
%%%
%%%=================================================================%%%

clear; clc; format long;

nu= 0.25;
E = 1;
a = 0.35;% FEA
R = 10;
h = 1;
d = 0.02;
r = 5;
a7 = 1/(4-4*nu);
G = E/(2+2*nu);

syms rho z mu real

%% general eigen-solutions
mu_num1 = [0.149522858069638
0.452922458277996 + 0.110144639735701i
0.773166076493511 + 0.137258070805968i
1.09014494931766 + 0.154402635982331i
1.40598325250537 + 0.167068909691672i
1.72127231824513 + 0.177140281916378i
2.03625016749252 + 0.185508246687080i
2.35103296157483 + 0.192669239991870i
2.66568470886971 + 0.198929170241373i
2.98024383136554 + 0.204490289372703i
3.29473486708559 + 0.209493394985405i
3.60917428064212 + 0.214040520543663i
3.92357355539854 + 0.218207998295580i
4.23794095980017 + 0.222054439166249i
4.55228260766389 + 0.225625833106521i
4.86660312265287 + 0.228958935177088i
5.18090606982162 + 0.232083586000193i
5.49519424459407 + 0.235024345642853i
5.80946984693376 + 0.237801617657410i
6.12373471428783 + 0.240432717961191i
6.43799028984153 + 0.242932238054171i
6.75223777920440 + 0.245312718058359i
7.06647818536610 + 0.247584986001425i
7.38071234988268 + 0.249758456084968i
7.69494098435539 + 0.251841364677005i
8.00916469478081 + 0.253840959014245i
8.32338400059447 + 0.255763649552955i
8.63759934971506 + 0.257615134063449i
8.95181113053968 + 0.259400499534517i
9.26601968159045 + 0.261124306486665i
9.58022529933387 + 0.262790659217754i
9.89442824456602 + 0.264403264707493i
10.2086287476626 + 0.265965482310063i
10.5228270129234 + 0.267480365911418i
10.8370232221888 + 0.268950699882664i
11.1512175378673 + 0.270379029893798i
11.4654101054844 + 0.271767689445304i
11.7796010558373 + 0.273118822812512i
12.0937905068268 + 0.274434404969457i
12.4079785650211 + 0.275716258957339i
12.7221653269956 + 0.276966071081021i
13.0363508804864 + 0.278185404251719i
13.3505353053870 + 0.279375709740686i
13.6647186746122 + 0.280538337565771i
13.9789010548493 + 0.281674545697538i
14.2930825072145 + 0.282785508242012i
14.6072630878270 + 0.283872322733951i
14.9214428483137 + 0.284936016654120i
15.2356218362528 + 0.285977553267392i
15.5498000955666 + 0.286997836865213i
15.8639776668684 + 0.287997717483664i
16.1781545877709 + 0.288977995158900i
16.4923308931603 + 0.289939423773412i
16.8065066154407 + 0.290882714539340i
17.1206817847530 + 0.291808539159295i
17.4348564291703 + 0.292717532699780i
17.7490305748736 + 0.293610296208017i
18.0632042463100 + 0.294487399099254i
18.3773774663347 + 0.295349381338247i
18.6915502563396 + 0.296196755435843i];

mu_real = [0.383170597
0.701558667
1.017346814
1.332369194
1.647063005
1.961585851
2.276008438
2.590367209
2.904682853
3.218967991
3.533230755
3.847476623
4.161709421
4.4759319
4.790146089
5.104353518
5.418555364
5.732752544
6.046945785
6.36113567
6.675322673
6.989507184
7.303689523
7.617869958
7.932048718
8.246225991
8.560401944
8.874576714
9.188750425
9.502923181
9.817095073
10.13126618
10.44543658
10.75960633
11.07377548
11.38794408
11.70211219
12.01627983
12.33044705
12.64461387
12.95878032
13.27294644
13.58711224
13.90127774
14.21544297
14.52960793
14.84377266
15.15793716
15.47210145
15.78626554
16.10042944
16.41459316
16.72875672
17.04292012
17.35708336
17.67124647
17.98540944
18.29957229
18.61373501];

mu_num = [-conj(mu_num1);-mu_real;mu_num1;mu_real];
% mu_num = [-conj(mu_num1);mu_num1];

% CharaM = [mu*a7*besselj(1,mu*R) (besselj(1,mu*R)-mu*a7*R*besselj(0,mu*R)) -(besselj(1,mu*R)-mu*a7*R*besselj(0,mu*R));0 -1i*besselj(1,mu*R) -1i*besselj(1,mu*R);-mu*a7*besselj(0,mu*R) -mu*a7*R*besselj(1,mu*R) mu*a7*R*besselj(1,mu*R)];
% Cvec23 = inv(CharaM(1:2,1:2))*CharaM(1:2,3);

phiit = [0;besselj(1,mu*rho);0;0;mu*rho*G*besselj(1,mu*rho);0];
Cvecs = [1;-besselj(0,mu*R)/(2*R*besselj(1,mu*R));besselj(0,mu*R)/(2*R*besselj(1,mu*R))];
phiis = [Cvecs(1)*mu*a7*besselj(1,mu*rho)+(besselj(1,mu*rho)-mu*rho*a7*besselj(0,mu*rho))*(Cvecs(2)-Cvecs(3));0;-mu*a7*(Cvecs(1)*besselj(0,mu*rho)+rho*besselj(1,mu*rho)*(Cvecs(2)-Cvecs(3)));mu*rho*G*(Cvecs(1)*2*mu*a7*besselj(1,mu*rho)+(besselj(1,mu*rho)-2*mu*rho*a7*besselj(0,mu*rho))*(Cvecs(2)-Cvecs(3)));0;2*mu*rho*a7*G*(-Cvecs(1)*mu*besselj(0,mu*rho)+(2*nu*besselj(0,mu*rho)-mu*rho*besselj(1,mu*rho))*(Cvecs(2)-Cvecs(3)))];

f = [];

for k_ = 1:length(mu_num)
    if k_ > length(mu_num)/2
        if k_ == length(mu_num)/2+1
            f = [f vpa(subs(exp(mu*(z-h)).*phiis,mu,mu_num(k_)))];
        elseif k_ <= length(mu_num)/2+length(mu_num1) && k_ > length(mu_num)/2+1
            f = [f vpa(real(subs(((real(subs(exp(mu*(z-h)),mu,mu_num(k_)))+imag(subs(exp(mu*(z-h)),mu,mu_num(k_)))*1i).*(real(simplify(subs(phiis,mu,mu_num(k_)),'Criterion','preferReal','Steps',100))+imag(simplify(subs(phiis,mu,mu_num(k_)),'Criterion','preferReal','Steps',100))*1i)),mu,mu_num(k_)))) vpa(imag(subs(((real(subs(exp(mu*(z-h)),mu,mu_num(k_)))+imag(subs(exp(mu*(z-h)),mu,mu_num(k_)))*1i).*(real(simplify(subs(phiis,mu,mu_num(k_)),'Criterion','preferReal','Steps',100))+imag(simplify(subs(phiis,mu,mu_num(k_)),'Criterion','preferReal','Steps',100))*1i)),mu,mu_num(k_))))];
        else
            f = [f vpa(subs(exp(mu*(z-h)).*phiit,mu,mu_num(k_)))];
        end
    else
        if k_ == 1
            f = [f vpa(subs(exp(mu*z).*phiis,mu,mu_num(k_)))];
        elseif k_ <= length(mu_num1) && k_ > 1
            f = [f vpa(real(subs((real(subs(exp(mu*z),mu,mu_num(k_)))+imag(subs(exp(mu*z),mu,mu_num(k_)))*1i).*(real(simplify(subs(phiis,mu,mu_num(k_)),'Criterion','preferReal','Steps',100))+imag(simplify(subs(phiis,mu,mu_num(k_)),'Criterion','preferReal','Steps',100))*1i),mu,mu_num(k_)))) vpa(imag(subs((real(subs(exp(mu*z),mu,mu_num(k_)))+imag(subs(exp(mu*z),mu,mu_num(k_)))*1i).*(real(simplify(subs(phiis,mu,mu_num(k_)),'Criterion','preferReal','Steps',100))+imag(simplify(subs(phiis,mu,mu_num(k_)),'Criterion','preferReal','Steps',100))*1i),mu,mu_num(k_))))];
        else
            f = [f vpa(subs(exp(mu*z).*phiit,mu,mu_num(k_)))];
        end
    end
end

% f03_0 = [0 0 1 0 0 0].';
% f04_0 = [0 rho 0 0 0 0].';
% f03_1 = [-nu*rho 0 0 0 0 E*rho].';
% f04_1 = [0 0 1 0 E*rho^2/(2+2*nu) 0].';
% 
% 
% f = [f03_0 f04_0 f03_1 f04_1 f];

%% Solve for the coefficients with variational method

%Parallel computing
pa=parpool(12);

Em = [];
Fm = [];

num_len = length(f(1,:));

parfor i_ = 1:num_len
    for j_ = 1:num_len
        temp1 = matlabFunction(transpose(f(4:6,i_))*f(1:3,j_),'vars',{rho,z});
        temp2 = matlabFunction(f(6,i_)*f(3,j_),'vars',{rho,z});
        temp3 = matlabFunction(transpose(f(1:2,i_))*f(4:5,j_),'vars',{rho,z});
        temp4 = matlabFunction(f(3,i_)*f(6,j_),'vars',{rho,z});
        Em(i_,j_) = -integral(@(rho) temp1(rho,h),0,R,'ArrayValued',true,'RelTol',0,'AbsTol',1e-20) + integral(@(rho) temp2(rho,0),0,a,'ArrayValued',true,'RelTol',0,'AbsTol',1e-20) - integral(@(rho) temp3(rho,0),0,R,'ArrayValued',true,'RelTol',0,'AbsTol',1e-20) - integral(@(rho) temp4(rho,0),a,R,'ArrayValued',true,'RelTol',0,'AbsTol',1e-20);
    end
    temp5 = matlabFunction(f(6,i_),'vars',{rho,z});
    Fm(i_) = integral(@(rho) (d-r+sqrt(r^2-rho^2))*temp5(rho,0),0,a,'ArrayValued',true,'RelTol',0,'AbsTol',1e-20);
    % str=['Waiting...',num2str(100*i_/num_len),'%'];
    % waitbar(i_/num_len,bar,str)
end
delete(pa);

Mm = inv(Em)*(Fm.');
ansvec = vpa(f*Mm)
uz = ansvec(3)

uuz = matlabFunction(uz);
fplot(@(rho) uuz(rho,0),[0,R]);
set(gca,'YDir','reverse');


%% verification of the symmetric distributions
% mu=-10:0.0001:10;
% J = abs(mu.*besselj(1,mu).*(besselj(1,mu).*besselj(0,mu)-(besselj(0,mu)).^2/(4-4*nu)-(besselj(1,mu)).^2/(4-4*nu)));
% J1 = abs((2*besselj(1,mu)-mu.*besselj(0,mu)));
% Y = bessely(0,mu);
% % plot(mu,J1)
% Y1 = bessely(1,mu);
% 
% plot(mu,imag(Y))
% hold on;
% plot(mu,imag(Y1))

% clear
% besselj1 = @(x)besselj(1,10*x)
% for n = 1:80
%     z(n) = fzero(besselj1,[(n-1) n]*pi/10);
% end
% z=z.'
